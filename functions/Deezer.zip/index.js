const artists = require('./data/artists.json');
const albums = require('./data/albums.json');
const tracks = require('./data/tracks.json');
const playlists = require('./data/playlists.json');
const moods = require('./data/moods.json');

async function query(event) {
  if (event.mood) {
    if (moods[event.mood]) return moods[event.mood];
  }
  if (event.hits) {
    if (event.hits === 'Album') return albums;
    if (event.hits === 'Artiste') return artists;
    if (event.hits === 'Morceau') return tracks;
    if (event.hits === 'Playlist') return playlists;
  }
  return artists;
}

module.exports.handler = async (event) => query(event);

// Uncomment this code below to test your function
(async function () {
  const event = {
    hits: 'Playlist',
    mood: 'anx',
  };
  const q = await query(event);
  console.log(JSON.stringify(q, null, 2));
}());
